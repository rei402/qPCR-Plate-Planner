# qPCR Plate Planner v2.1.2 · Apple 主屏幕 App

交付日期：2026-10-12。打开同目录“qPCR Plate Planner Apple 安装教程.html”或“安装教程.md”查看安装步骤。

软件入口：https://qpcr-plate-planner-ipad-v212.kumalovetutu.chatgpt.site/qPCR%20Plate%20Planner.html

“网页部署文件”用于静态 HTTPS 托管或备份；请通过 Safari 在线安装主屏幕 App。ZIP 本身不是 IPA，不能直接点 ZIP 安装。核心运行文件与冻结版逐字节相同。
